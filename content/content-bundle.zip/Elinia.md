---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Region--Geographical
Geographical-Region: Mountains
Terrain: Swamp
Climate: Arctic
parent:
 - Region_ Geographical
up:
 - Region_ Geographical
prev:
 - Template - Region_ Deimensional
next:
 - Template - Region_ Political
RWtopicId: Topic_25
Alignment: N/A
Type: Planet
---
# Elinia - Planet



```leaflet
### Tutorial: https://youtu.be/54EyMzJP5DU
### id must be unique
id: Elina-Map
### Lock pins so they can't be moved
lock: false
### If true, view of map will recenter as you zoom out. 
recenter: true
### If true, disables mouse scroll for zomming in and out of a map. Button controls still work. 
noScrollZoom: false
image: [[622ff471-488b064e.png]]
### Map Pixel Height x 1 / (Pixels between Bar Scale / 100)
### Map Pixel Width x 1 / (Pixels between Bar Scale / 100) 
### Note that this formula requires adjustments depending on your map. The idea is to determine the number of units between your bar scale. We divide by 100 here because my bar scale measures in 100 units. If your maps scale bar measures in units of 50 them you should divide by 50 instead. The idea is to calculate how many pixels are equal to 1 unit. 
bounds: [[0,0], [16054.8, 24027.3]]
height: 1100px
width: 90%
### This sets where the map starts by default. Set it to the middle (half) of your bounds. 
lat: 4527.4
long: 7,513.5
### 0 is no zoom. Negative zoom steps away from the map. Positive zoom steps towards the map. 
minZoom: -50.5
### Max zoom is 18. 
maxZoom: 1.5
### Hover mouse over the Reset Zoom icon to see your current zoom level. 
defaultZoom: -4
### How far it zooms in or out with each step. Can be in decimals. 
zoomDelta: 0.5
### This is a string so can be any text. Change it to match your maps measurement scale. 
unit: KM
scale: 1
darkMode: false
```




## Overview
**Geographical Region**: Mountains, Hills, Plains, Forest, Swamp, Marsh, Jungle, Rainforest, Lake, River, Bay, Reef, Peninsula, Isthmus, Strait, Cove, Delta, Canyon, Glacier, Plateau, Valley, Oasis, Coast, Pass, Continent, Subcontinent, Island, Archipelago, Other, Travel Route, Body of Water, Gulf, Ocean, Sea

Ruled over by [[The House]]

## Description
**Terrain**: Swamp, Jungle, Rocky, Treacherous, Rainforest, Badlands, Croplands, Deserts, Forests, Grasslands, Hills, Mountains, Other, Tundra, Underground, Urban, Water, Marsh, Coastal, Volcanic

**Climate**: Arctic, Arid, Other, Subtropical, Temperate, Tropical ;


## Notable NPCs
Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
[[The Shivering Expanse]]
[[City of Wehstead]]
[[Anarduk Basin Superorganism - Sumuta]]
[[Elcier Landing]]
[[Backrooms Maze]]
[[The Shivering Expanse]]
[[Bowldur]]
[[CAER KONIG]]
[[Leininbrooke]]
[[Oakenfeld]]
[[Neverwinter]]
[[Silbernvein]]
## Resources
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

