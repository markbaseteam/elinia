---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Adventure-Area
Type: Building
parent:
 - Adventure Area
up:
 - Adventure Area
prev:
 - Template - Group_ Religious
next:
 - Template - Location
RWtopicId: Topic_20
Alignment: N/A
---
# Template - Adventure Area
## Overview
**Type**: Building, Area, Cavern, Complex, Dungeon, Fortress, Installation, Other, Ruin, Temple

Placeholder

## Description


## Notable NPCs
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Challenges
Placeholder

## Obstacles
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

