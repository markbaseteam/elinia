---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Location
Type: Area
parent:
 - Location
up:
 - Location
prev:
 - Template - Adventure Area
next:
 - Template - Merchant
RWtopicId: Topic_21
Alignment: N/A
---
# Template - Location
## Overview
**Type**: Area, Facility, Point of Interest, Compound, Access Point, Anomaly, Building, Chamber, Corridor, Landmark, Level, Marker, Open Space, Other, Room, Waypoint

Placeholder

## Description
### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Challenges
Placeholder

## Obstacles
Placeholder

## Relationships
[[Elcier Landing]]

## Background
Placeholder

## Additional Details
Placeholder

