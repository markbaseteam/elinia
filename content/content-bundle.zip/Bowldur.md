---
Alignment: Neutral
Political-Region: 
Community-Size: 
Government: 
Type: 
Terrain: 
Climate: 
Geographical-Region: 
Tags: 
---
