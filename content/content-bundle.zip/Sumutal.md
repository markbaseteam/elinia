---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Settlement
Community-Size: Outpost
Alignment: Chaotic Evil
Government: Theocracy 
parent:
 - Settlement
up:
 - Settlement
prev:
 - Template - Region_ Area
next:
 - Template - Inhabitant
RWtopicId: Topic_28
Political-Region: City
Type: City
---
# Template - Settlement
## Overview
**Community Size**: Outpost

**Alignment**: Chaotic Evil

**Government**: Autocracy, Bureaucracy, Confederacy, Democracy, Dictatorship, Feudalism, Gerontocracy, Hierarchy, Kleptocracy, Magocracy, Matriarchy, Meritocracy, Militocracy, Monarchy, Oligarchy, Patriarchy, Plutocracy, Republic, Satrapy, Theocracy ;

**Defense**: Placeholder

**Commerce**: Placeholder

**Organizations**: Placeholder

Placeholder

## Description
**Population**: Placeholder

### Placeholder Map
![[z_Assets/Misc/MapPlaceholder.png|Placeholder Map]]
[[z_Assets/Misc/MapPlaceholder.png|open outside]]

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Notable NPCs
Placeholder

## Profile
Placeholder

## Story


```timeline
UniqueTimelineID
```




## Points of Interest
Placeholder

## Valuables
Placeholder

## Internal Relationships
Placeholder

## Outward Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

