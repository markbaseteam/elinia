---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Location
Type: City
parent:
 - Location
up:
 - Location
prev:
 - Template - Adventure Area
next:
 - Template - Merchant
RWtopicId: Topic_21
Political-Region: City
---
# Leininbrooke
## Overview
**Type**: City



## Description
## Leininbrooke
![[leininbrooke.png|Leininbrooke]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]




## Points of Interest
### Population:

-   Approximately 21000; primarily human, some halfling.

### Government:

-   Leininbrooke is governed by a noble aristocrat, the halfling lady Tlinchitlaco, though several legendary adventurers wield limited power.

### Notable Places:

-   Ahuatzin's Casting: A single storey half-timbered building, the workshop of a female human founder named Ahuatzin. She has been cursed by a hag, and every torc she casts makes its wearer more susceptible to magical charms and compulsions.
-   Capantzina's Masonry: The workshop of a female human stonemason named Capantzina, who is rumored to be quarrying stone from a cursed ruins.
-   Alcochin's Masonry: The workshop of a female human stonemason named Alcochin, who seems to know every dungeon within twenty leagues of town.

### A few NPCs:

-   Huanitzin: Male Human Soldier, Evil. Huanitzin is repulsive in appearance, with brown hair and narrow grey eyes. He wears scale mail and wields a flail and shield. Huanitzin has a deadly allergy to elves.
-   Tlacatzotz: Male Human Fighter, Good. Tlacatzotz is common in appearance, with golden hair and brown eyes. He wears splint mail and wields a military fork. Tlacatzotz is energetic and lewd.
-   Camanena: Female Human Artist, Neutral. Camanena has silver hair and soft grey eyes, and a round nose. She wears modest garments and carries a fine stiletto. Camanena is hunting the sorceress who stole her husband.
-   Temalpop: Male Human Entertainer, Evil. Temalpop has tangled grey hair and dark green eyes, and a long moustache. He wears modest garments and a silver holy symbol. Temalpop lost his reflection to a hag.
-   Atzin: Male Human Thief, Good. Atzin is rough in appearance, with messy blonde hair and brown eyes. He wears leather armor and wields a long sword and dagger. Atzin seeks to discover why he keeps having the same dream.
-   Nocatli: Male Human Aristocrat, Good. Nocatli is overweight, with thick auburn hair and grey eyes. He wears fine raiment and several pouches hang from his belt. Nocatli is searching for his lost brother.

## Bell Borough

### Notable Places:

-   Zealot's Corner: Zealots and madmen can often be encountered here, shouting their rambling dogmas at bemused passers-by.
-   The Odeum of Voices: A two-storey theatre of timber and brick walls, home of a thieves' guild pretending to be dancers.

### A few NPCs:

-   Tazina: Male Human Illusionist, Neutral. Tazina has a square face, with curly silver hair and amber eyes. He wears modest garments and wields a quarterstaff. Tazina was raised by cultists of the Forlorn Empress.
-   Tetlaca: Male Human Assassin, Good. Tetlaca is thin, with copper hair and green eyes. He wears leather armor and wields a long sword. Tetlaca is searching for the legendary dwarven kingdom of Badushizd.
-   Tlehiuhtli: Male Human Mercenary, Good. Tlehiuhtli has golden hair and grey eyes, and an uneven moustache. He wears scale mail and wields a battle axe. Tlehiuhtli has an animal companion, a white rabbit named Atzin.

## Brightarch District

### Notable Places:

-   The Asylum: A two-storey half-timbered building, filled with the madmen and lunatics of the town.
-   Tecahitli's Anvil: A large blacksmith's workshop, built around a shrine of Tinacalxoch, Goddess of Fire.
-   Temalpip's Arsenal: A large weaponsmith's workshop, decorated with a collection of sundered shields.

### A few NPCs:

-   Malaxoche: Female Human Illusionist, Neutral. Malaxoche is exceptionally beautiful, with golden hair and hazel eyes. She wears plain clothing and wields a dagger and darts. Malaxoche seeks to raise an army of flesh golems.
-   Anin: Male Dwarf Craftsman, Good. Anin has matted brown hair and soft green eyes, and walks with a limp. He wears well-made clothing and several pouches hang from his belt. Anin is easily distracted by arcana.

## Brightwood Borough

### Notable Places:

-   A spire of hewn stone, placed to honor a local goddess of fate.
-   The Crossed Swords: A neglected dwarven tavern, said to be haunted by the ghost of a silver dragon.
-   Acatzihuatl's Blades: The workshop of a female human weaponsmith named Acatzihuatl, who was once an adventurer, but retired after her companions were slain in the Halls of Bela the Awesome.

### A few NPCs:

-   Cochtzina: Male Halfling Soldier, Evil. Cochtzina is repulsive in appearance, with auburn hair and brown eyes. He wears scale mail and wields a mace and light crossbow. Cochtzina is hunting the sorceress who stole his husband.
-   Capalxoche: Female Halfling Servant, Neutral. Capalxoche is heavyset, with white hair and dark hazel eyes. She wears sturdy clothing and several pouches hang from her belt. Capalxoche lost her right eye to an injury.
-   Tetlaltoa: Male Human Cleric, Neutral. Tetlaltoa is common in appearance, with matted white hair and brown eyes. He wears banded mail and wields a quarterstaff. Tetlaltoa has an animal companion, a white rabbit named Ichpochin.
-   Totlaxoche: Female Human Fighter, Neutral. Totlaxoche has straight white hair and dark brown eyes. She wears banded mail and wields a spear. Totlaxoche has an animal companion, a brown bear named Quauhtzina.
-   Acoahual: Male Halfling Paladin, Good. Acoahual is youthful in appearance, with blonde hair and brown eyes. He wears banded mail and wields a glaive-guisarme. Acoahual is perceptive but thoughtless.

## Charger's Borough

### Notable Places:

-   The Pool of Inyebrias: A large stone basin filled with frozen water. It is said that the pool sometimes reveals visions of the future to those who gaze into it long enough.

### A few NPCs:

-   Pantzinetzin: Female Human Aristocrat, Good. Pantzinetzin is youthful in appearance, with copper hair and hazel eyes. She wears fine raiment and a gold amulet. Pantzinetzin seeks to discover the truth of her lineage.
-   Popili: Male Human Priest, Neutral. Popili is fey in appearance, with copper hair and hazel eyes. He wears fine clothing and a sling of vials and potions. Popili has a deadly allergy to horses.
-   Toztloxoche: Female Human Alchemist, Good. Toztloxoche is short, with brown hair and brown eyes. She wears modest garments and a sling of vials and potions. Toztloxoche is dying and desperately seeks the secret of immortality.
-   Malacapo: Female Halfling Illusionist, Evil. Malacapo is beastly in appearance, with thin brown hair and dark hazel eyes. She wears travel-stained clothing and wields a dagger. Malacapo is vulgar and vengeful.
-   Capantzina: Female Halfling Soldier, Evil. Capantzina has a narrow face, with white hair and sharp grey eyes. She wears leather armor and wields a mace and long bow. Capantzina is searching for her missing daughter.

## Coin District

### Notable Places:

-   A broken temple ruins, which appears restored upon the night of the new moon.
-   Atzin's Woodwork: A modest woodcarver's workshop, built within a copse of rowan trees.
-   The Druid's Hedge: This old hedge is the home of Zinaca, an elven druid who became stuck in the shape of a red fox long ago.

### A few NPCs:

-   Imahualxotl: Female Halfling Scholar, Good. Imahualxotl has thick grey hair and soft amber eyes, and an unusual mark on her leg. She wears tailored clothing and an amulet of luminous crystal. Imahualxotl is a skilled singer.
-   Quauhxochuitzin: Female Human Scofflaw, Good. Quauhxochuitzin has auburn hair and soft brown eyes, and a distinctive mark on her arm. She wears well-made clothing and a white cloak. Quauhxochuitzin is sensitive and gentle.
-   Quitzompop: Male Halfling Peasant, Neutral. Quitzompop is fair in appearance, with thick copper hair and grey eyes. He wears modest garments and a wide-brimmed hat. Quitzompop secretly serves Raksha, an ancient undead god.

## Crown Village

### Notable Places:

-   The Human's Pottery: The workshop of a male human named Terfa, who throws and fires his wares at the same time. He specializes in chalices inscribed with invocations of elemental fire, favored by cults.

### A few NPCs:

-   Calxochitli: Female Halfling Ranger, Neutral. Calxochitli is thin, with cropped white hair and brown eyes. She wears leather armor and wields a mace and heavy crossbow. Calxochitli is inventive and humble.
-   Imacatl: Female Human Servant, Neutral. Imacatl is tall and heavyset, with red hair and blue eyes. She wears simple clothing and a red cloak. Imacatl is bold and flirtatious.
-   Anitel: Male Human Scofflaw, Good. Anitel has short white hair and large hazel eyes, and a thin moustache. He wears travel-stained clothing and several pouches hang from his belt. Anitel has an animal companion, a white rabbit named Xopocoyo.

## Ford Village

### Notable Places:

-   The Sword of Lightning: A shabby elven inn, built within what was once a minor temple.

### A few NPCs:

-   Tzinacui: Male Human Scholar, Good. Tzinacui has brown hair and grey eyes. He wears expensive clothing and a silver holy symbol. Tzinacui is searching for his lost sister.
-   Tacapantzin: Female Human Paladin, Good. Tacapantzin is common in appearance, with tangled brown hair and dark brown eyes. She wears chain mail and wields a long sword and shield. Tacapantzin has an animal companion, a black warhorse named Antzimatzin.
-   Quequitoa: Male Human Merchant, Neutral. Quequitoa is short, with uneven copper hair and hazel eyes. He wears plain clothing and riding boots. Quequitoa is irreverent and guarded.
-   Nitzina: Male Human Ranger, Evil. Nitzina has curly red hair and brown eyes. He wears chain mail and wields a military pick and short bow. Nitzina is greedy but diplomatic.

## Hartsfair Borough

### Notable Places:

-   Nalacapo's Ironworks: The workshop of a female human blacksmith named Nalacapo, who is rumored to possess a small hoard of demonic iron.
-   Tlinchitloco's Pottery: The workshop of a female human potter named Tlinchitloco, who was once a great wizard, but retired to marry and raise a family.
-   Tlancacuichpo's Pottery: A cluttered potter's workshop, built around a shrine of Tlacihizin, Lady of Earth.

### A few NPCs:

-   Totecalxoch: Female Human Wizard, Good. Totecalxoch has a round face, with copper hair and blue eyes. She wears sturdy clothing and wields a dagger and sling. Totecalxoch has an arcane familiar, a silver cat wearing a tiny backpack.
-   Uahuetzitl: Female Human Fighter, Evil. Uahuetzitl is fair in appearance, with uneven grey hair and bright amber eyes. She wears chain mail and wields a bastard sword and short bow. Uahuetzitl is hunting the brigands who murdered her family.
-   Cenopantl: Male Human Artist, Evil. Cenopantl has straight auburn hair and amber eyes. He wears modest garments and an amulet of luminous crystal. Cenopantl is deceitful but brave.

## Knightsgate District

### Notable Places:

-   The Harper and Cup: An elegant elven tavern, said to be a front for the Thieves' Guild.
-   Celi's Carvings: The workshop of a male human woodcarver named Celi, who is rumored to have arranged the murder of the previous guildmaster.
-   The Jester's Pub: A neglected elven inn, which has one door here and another in Tlaoxtepec, the City of Coins.

### A few NPCs:

-   Tlocapantzin: Female Human Necromancer, Evil. Tlocapantzin is tall and willowy, with black hair and blue eyes. She wears modest garments and wields a dagger. Tlocapantzin dislikes everyone except other humans.
-   Tleha: Male Human Fighter, Evil. Tleha is short, with messy white hair and soft amber eyes. He wears banded mail and wields a battle axe and shield. Tleha is hunting the giant who slew his mentor.
-   Teotlalli: Male Halfling Mercenary, Good. Teotlalli is willowy, with thick copper hair and narrow hazel eyes. He wears chain mail and wields a battle axe and light crossbow. Teotlalli is colorblind.
-   Tlillinchuatzin: Female Human Druid, Neutral. Tlillinchuatzin has copper hair and grey eyes, and large ears. She wears leather armor and wields a spear and sling. Tlillinchuatzin is covetous, and always has her eye on something she wants.
-   Ancotzin: Male Dwarf Entertainer, Neutral. Ancotzin is fey in appearance, with thin blonde hair and soft amber eyes. He wears fine clothing and a copper amulet. Ancotzin is a pack-rat, and carries a satchel of random junk.

## Lion's Village

### Notable Places:

-   An arch of obsidian, said to entomb the bones of a local wizard.
-   Tlixcama's Carvings: The workshop of a male human woodcarver named Tlixcama, known for his staves and wands, favored by the Astrologers Guild.
-   Acacoc's Pewter: A large pewtersmith's workshop, decorated with sinister pewter faeries.

### A few NPCs:

-   Totloxoche: Female Human Druid, Neutral. Totloxoche has auburn hair and green eyes. She wears leather armor and wields a club. Totloxoche is searching for the lost dominion of Eglast.
-   Maloxoche: Female Human Thief, Neutral. Maloxoche is exceptionally beautiful, with brown hair and blue eyes. She wears leather armor and wields a dagger. Maloxoche is haunted by the ghost of someone she killed.
-   Acalitl: Female Human Fighter, Evil. Acalitl has long white hair and amber eyes, and prominent ears. She wears plate mail and wields a flail. Acalitl is secretive but wise.
-   Uatzacapal: Female Human Fighter, Evil. Uatzacapal has auburn hair and blue eyes, and a round nose. She wears plate mail and wields a warhammer and javelins. Uatzacapal is hunting the sorceress who stole her husband.

## Market

### Notable NPCs:

-   Colhnitzin: Male Human Poulter, Good. Colhnitzin has white hair and light blue eyes, and walks with a limp. He wears modest garments and a wide-brimmed hat. Colhnitzin is known for his brightly hued peacock sausages.
-   Tlepochu: Male Human Guard, Good. Tlepochu is courtly in bearing, with grey hair and sharp grey eyes. He wears leather armor and wields a warhammer and shield. Tlepochu has been hunting the legendary thief Wina for many years.

## Scepter Borough

### Notable Places:

-   The Broken Fang: A neglected commoner's inn, brightly lit by magical candles and crystal chandeliers.

### A few NPCs:

-   Xochuema: Male Human Fighter, Evil. Xochuema has brown hair and brown eyes, and walks with a limp. He wears banded mail and wields a mace and short bow. Xochuema seeks to save his family from financial ruin.
-   Toquihue: Male Human Necromancer, Evil. Toquihue has long red hair and brown eyes. He wears dark robes and wields a club and darts. Toquihue holds a grudge against elves.
-   Chuictema: Male Halfling Peasant, Evil. Chuictema is repulsive in appearance, with golden hair and blue eyes. He wears simple clothing and a bronze amulet. Chuictema seeks to fulfill an ancient prophecy of evil.
-   Cuichpantiaco: Female Human Paladin, Good. Cuichpantiaco has a narrow face, with curly auburn hair and amber eyes. She wears plate mail and wields a warhammer and shield. Cuichpantiaco has an animal companion, a black warhorse named Malmiyahe.
-   Zina: Male Human Artist, Good. Zina has red hair and light grey eyes, and a messy beard. He wears tailored clothing and silk gloves. Zina has an animal companion, a green firedrake named Totacahe.

## Temple District

### Notable Places:

-   The Tavern of the Endless Round: A shabby dwarven tavern, known for a magical wall upon which are always exactly 99 bottles of ale. The tavern is named for a simple song about the wall sung by its patrons, which has been going more-or-less continuously for the last century.
-   Acitlatotl's Armaments: The workshop of a female human weaponsmith named Acitlatotl, who was once an adventurer, but retired after her companions were lost in the Dread Tunnels of the Goblin King.

### A few NPCs:

-   Cuetlaxoche: Female Halfling Merchant, Neutral. Cuetlaxoche is exceptionally beautiful, with matted blonde hair and soft blue eyes. She wears modest garments and a wooden holy symbol. Cuetlaxoche seeks to discover what destroyed her homeland.
-   Toquihu: Male Dwarf Fighter, Neutral. Toquihu has blonde hair and narrow grey eyes. He wears splint mail and wields a battle axe and shield. Toquihu is shrewd and modest.
-   Quiauhxochtzina: Female Human Soldier, Evil. Quiauhxochtzina is exceptionally beautiful, with thick auburn hair and bright amber eyes. She wears scale mail and wields a battle axe. Quiauhxochtzina seeks to fulfill an ancient prophecy of evil.
-   Tlixcoatzin: Male Halfling Mercenary, Good. Tlixcoatzin is stout, with golden hair and sharp grey eyes. He wears studded leather and wields a battle axe and shield. Tlixcoatzin has an animal companion, a sable ferret named Xayactexca.

## Tome Village

### Notable Places:

-   The Academy of Elemental Study: A venerable school of witches and wizards, built within a floating tower.
-   Tacapanteot's Arsenal: A neglected weaponsmith's workshop, built atop an outcrop of volcanic rock.
-   The Shrine of Xayaca: A stone niche enshrining an idol of Xayaca, Lord of Courage, said to bestow favor to those who leave an offering.

### A few NPCs:

-   Panopantin: Female Human Peasant, Evil. Panopantin has a long face, with white hair and hazel eyes. She wears modest garments and a wide-brimmed hat. Panopantin has an acute fear of clerics.
-   Miahiutalco: Female Human Fighter, Good. Miahiutalco is short, with cropped golden hair and grey eyes. She wears chain mail and wields a military fork. Miahiutalco has a deadly allergy to moulds and oozes.
-   Tinetzina: Female Halfling Assassin, Neutral. Tinetzina is exceptionally beautiful, with black hair and narrow green eyes. She wears leather armor and wields a short sword and darts. Tinetzina is pleasant and decisive.
-   Ahuelhuatl: Female Human Ranger, Evil. Ahuelhuatl has long copper hair and sharp amber eyes, and pointed ears. She wears studded leather and wields a bastard sword. Ahuelhuatl is hunting the sorcerer who murdered her family.

## Upper Scepter Farthing

### Notable Places:

-   The Clockwork: A large sphere of rotating gears and ticking escapements, crafted from brass and inscribed with incoherent labyrinths. No-one seems to know who created it, nor when, nor its purpose.
-   The Midnight Theatre: A grand timber and brick theatre, known for its monstrous slice of life plays.
-   The Odeum of Achon: A grand half-timbered theatre, which seems to be bigger on the inside than on the outside.

### A few NPCs:

-   Tinopalxoch: Female Human Fighter, Good. Tinopalxoch has a long face, with matted grey hair and bright grey eyes. She wears plate mail and wields a bastard sword and shield. Tinopalxoch holds a grudge against clerics.
-   Imetl: Male Human Merchant, Neutral. Imetl is fey in appearance, with brown hair and narrow hazel eyes. He wears plain clothing and a gray cloak. Imetl has an animal companion, a sable ferret named Atzin.
-   Tacuelhitli: Female Human Craftsman, Good. Tacuelhitli is exceptionally beautiful, with tangled white hair and green eyes. She wears travel-stained clothing and several pouches hang from her belt. Tacuelhitli is a terrible liar.

## Wood District

### Notable Places:

-   The Broken Fang: An elegant adventurer's tavern, built around a hewn stone impaled by a sword.

### A few NPCs:

-   Acompac: Male Human Priest, Neutral. Acompac has short black hair and blue eyes, and prominent ears. He wears modest garments and silk gloves. Acompac is humble and bold.
-   Tzineca: Male Halfling Fighter, Evil. Tzineca has brown hair and bright brown eyes, and a thin mouth. He wears banded mail and wields a battle axe and long bow. Tzineca has an animal companion, a black bear named Capanetzin.
-   Tlaca: Male Human Aristocrat, Good. Tlaca has auburn hair and light hazel eyes, and a pattern of unusual marks on his neck. He wears fine raiment and jewelry. Tlaca has an animal companion, a red fox named Mixaochizin.

## Valuables
Placeholder

## Challenges
Placeholder

## Obstacles
Placeholder

## Relationships
[[Elinia]]
[[Oakenfeld]]


## Background
Placeholder

## Additional Details
| Other | The city has 108 noble houses. The peace is kept by 72 guardsmen, and there are 47 advocates to assist with legal matters. For those more concerned about their soul, there are 291 clergymen and 25 priests. |
|-------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Size | The city of Leininbrooke covers an area of approximately 346 acres, with a total population of 21 thousand people. |
|------|--------------------------------------------------------------------------------------------------------------------|

---

| Bakers | 23 | Butchers | 27 | Furriers | 110 | Magic Shops | 8 | Roofers | 12 | Tanners | 16 |
|--------|----|----------|----|----------|-----|-------------|---|---------|----|---------|----|

| Barbers | 70 | Carpenters | 41 | Glovemakers | 4 | Maidservants | 91 | Ropemakers | 12 | Taverns | 71 |
|---------|----|------------|----|-------------|---|--------------|----|------------|----|---------|----|

| Bathers | 12 | Chandlers | 27 | Harness-makers | 15 | Masons | 46 | Rugmakers | 12 | Watercarriers | 30 |
|---------|----|-----------|----|----------------|----|--------|----|-----------|----|---------------|----|

| Beer-sellers | 10 | Chicken Butchers | 20 | Hatmakers | 33 | Mercers | 29 | Saddlers | 18 | Weavers | 28 |
|--------------|----|------------------|----|-----------|----|---------|----|----------|----|---------|----|

| Blacksmiths | 7 | Coopers | 16 | Hay Merchants | 13 | Old Clothes | 51 | Scabbardmakers | 33 | Wine-sellers | 21 |
|-------------|---|---------|----|---------------|----|-------------|----|----------------|----|--------------|----|

| Bleachers | 13 | Copyists | 7 | Illuminators | 7 | Painters | 12 | Sculptors | 7 | Woodcarvers | 6 |
|-----------|----|----------|---|--------------|---|----------|----|-----------|---|-------------|---|

| Bookbinders | 9 | Cutlers | 3 | Inns | 11 | Pastrycooks | 42 | Shoemakers | 97 | Woodsellers | 11 |
|-------------|---|---------|---|------|----|-------------|----|------------|----|-------------|----|

| Booksellers | 4 | Doctors | 9 | Jewelers | 37 | Plasterers | 8 | Spice Merchants | 6 |
|-------------|---|---------|---|----------|----|------------|---|-----------------|---|

| Buckle Makers | 23 | Fishmongers | 8 | Locksmiths | 17 | Pursemakers | 14 | Tailors | 43 |
|---------------|----|-------------|---|------------|----|-------------|----|---------|----|
