---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Settlement
Community-Size: Metropolis
Alignment: Neutral
Government: Autocracy
parent:
 - Settlement
up:
 - Settlement
prev:
 - Template - Region_ Area
next:
 - Template - Inhabitant
RWtopicId: Topic_28
Type: Metropolis
Political-Region: Metropolis
---
# Elcier Landing
## Overview
**Community Size**: Major city

**Government**: Elcier Landing is governed by several wealthy aristocrats, who are secretly backed by a lich named Siuferha.


**Commerce**: The city's gold piece limit is 100,000 gp. Anything, whether it be mundane or magical, having a price under that limit is most likely available for purchase. The total amount of available coinage, or the total value of any given item of equipment for sale at any given time, is 250,000,000 gp.

![[0d0d5488a090b2050c7cbf52b64ee7ca (1).png]]



#### SIZE

The city of Elcier Landing covers an area of approximately 824 acres, with a total population of 50 thousand people. The population is mostly human (79%), with smaller numbers of halflings (9%), elves (5%), dwarves (3%), gnomes (2%), half-elves (1%) and half-orcs (1%).



## Description
**Population**: 50,000


### Districts

### Archsword Village

 

#### NOTABLE PLACES:

 

-   The Guildhall: An ornate half-timbered building, once an aristocrat's manor. It contains a large meeting hall and several smaller rooms, and is shared amongst several local trade guilds.
-   The Hooded Witch: A shabby adventurer's tavern, known for the illusions which entertain its patrons.

#### A FEW NPCS:

 

-   Adjesnes: Female Dwarf Necromancer, Evil. Adjesnes has curly copper hair and light grey eyes, and a wide mouth. She wears modest garments and wields a short sword and dagger. Adjesnes is jovial but scheming.
-   Tibu: Female Dwarf Priest, Neutral. Tibu has an angular face, with copper hair and dark amber eyes. She wears tailored clothing and silk gloves. Tibu has an animal companion, a white rabbit named Munhonsu.
-   Nefermy: Male Dwarf Ranger, Good. Nefermy is cultured in appearance, with tangled grey hair and grey eyes. He wears studded leather and wields a mace. Nefermy has a badger named Tymuni.
-   Iretkakht: Female Human Cleric, Good. Iretkakht has black hair and hazel eyes, and a pattern of distinctive marks on her face. She wears splint mail and wields a flail. Iretkakht has an animal companion, a silver cat named Sute.
-   Messeru: Male Dwarf Thief, Good. Messeru has matted auburn hair and dark green eyes. He wears leather armor and wields a short sword and dagger. Messeru is easily distracted by magic.

### Charger's Ward

 

#### NOTABLE PLACES:

 

-   The ruins of Ibrefet Tower.

#### A FEW NPCS:

 

-   Irymer: Male Dwarf Fighter, Evil. Irymer has copper hair and bright green eyes. He wears splint mail and wields a long sword and shield. Irymer lost his right eye to an injury.
-   Paire: Male Dwarf Craftsman, Evil. Paire is tall, with uneven silver hair and light blue eyes. He wears well-made clothing and carries a willow staff. Paire is reckless but idealistic.
-   Neithabu: Female Dwarf Assassin, Evil. Neithabu has thick copper hair and bright hazel eyes, and a thin nose. She wears leather armor and wields a poisoned short sword and darts. Neithabu is adaptable and adventurous.
-   Djahoty: Male Elf Fighter, Neutral. Djahoty has black hair and amber eyes, and a braided moustache. He wears banded mail and wields a battle axe and shield. Djahoty is tactless and cynical.
-   Khonse: Male Dwarf Assassin, Neutral. Khonse has a long face, with thick copper hair and blue eyes. He wears leather armor and wields a poisoned short sword and sling. Khonse is stubborn and quiet.
-   Minakhte: Female Human Peasant, Neutral. Minakhte is fey in appearance, with straight copper hair and hazel eyes. She wears plain clothing and riding boots. Minakhte has a silver dog named Tjedkha.

### Crystalford Ward

 

#### NOTABLE PLACES:

 

-   Neferoy's Masonry: A large stonemason's workshop, built within a ring of ancient stone monoliths.
-   Irefet's Masonry: A large stonemason's workshop, said to be guarded by living gargoyles.
-   A broken spire of rune-carved stone, said to entomb a relic of Tjeduathue, Lady of Plague.

#### A FEW NPCS:

 

-   Mehiahu: Female Dwarf Druid, Neutral. Mehiahu is exceptionally beautiful, with silver hair and amber eyes. She wears leather armor and wields a scimitar. Mehiahu is craven but witty.
-   Tenihay: Female Dwarf Wizard, Evil. Tenihay is exceptionally beautiful, with golden hair and sharp blue eyes. She wears tailored clothing and wields a quarterstaff and dagger. Tenihay seeks to raise an army of gargoyles.
-   Kahmenwy: Male Dwarf Craftsman, Evil. Kahmenwy has a square face, with braided black hair and large blue eyes. He wears travel-stained clothing and a wide-brimmed hat. Kahmenwy is guarded and zealous.
-   Pahonse: Male Dwarf Fighter, Neutral. Pahonse is common in appearance, with white hair and large brown eyes. He wears banded mail and wields a long sword. Pahonse has an animal companion, a badger named Khirkere.
-   Djakhore: Male Dwarf Mercenary, Good. Djakhore is tall, with matted white hair and dark grey eyes. He wears leather armor and wields a mace and long bow. Djakhore is instinctive and irreverent.
-   Rerety: Female Dwarf Scholar, Good. Rerety has curly red hair and dark grey eyes. She wears modest garments and a feathered hat. Rerety seeks to free herself from an ancient curse.

### Demon's Village

 

#### NOTABLE PLACES:

 

-   The Astrologers Guild Hall: A single storey building hewn from an outcrop of rock, said to be haunted by the ghost of an arch-wizard.

#### A FEW NPCS:

 

-   Nofre: Female Human Paladin, Good. Nofre has copper hair and amber eyes, and pointed ears. She wears chain mail and wields a flail and shield. Nofre is reflective but sharp-tongued.
-   Nesmere: Female Dwarf Merchant, Good. Nesmere is short, with copper hair and grey eyes. She wears well-made clothing and riding boots. Nesmere has an animal companion, a white rabbit named Neferu.
-   Mehtatiaa: Female Dwarf Fighter, Evil. Mehtatiaa has braided red hair and amber eyes, and a small mouth. She wears plate mail and wields a short sword and shield. Mehtatiaa serves a powerful arch-fiend named Gleosa.
-   Retephuy: Female Dwarf Thief, Evil. Retephuy is fey in appearance, with white hair and green eyes. She wears leather armor and wields a club. Retephuy was magically imprisoned for a hundred years.

### Dock Ward

 

#### NOTABLE PLACES:

 

-   An overgrown temple ruins, which appears restored upon the night of the equinox.
-   The Guildhall: A large half-timbered building, decorated with a glazed-tile roof. It contains a large meeting hall and several smaller rooms, and is shared amongst several local trade guilds.
-   The Guildhall: A grand half-timbered building, once a minor temple. It contains a large meeting hall and several smaller rooms, and is shared amongst several local trade guilds.

#### A FEW NPCS:

 

-   Nefukhy: Male Human Fighter, Evil. Nefukhy is heavyset, with cropped copper hair and dark hazel eyes. He wears banded mail and wields a mace. Nefukhy is kind and amoral.
-   Setnubkhuy: Female Elf Assassin, Good. Setnubkhuy has thick golden hair and hazel eyes. She wears leather armor and wields a poisoned long sword and dagger. Setnubkhuy has an animal companion, a black viper named Hotefi.
-   Pety: Male Human Craftsman, Neutral. Pety has red hair and bright hazel eyes, and walks with a limp. He wears travel-stained clothing and a black cloak. Pety seeks to save his family from financial ruin.
-   Irefet: Female Dwarf Merchant, Good. Irefet is short, with silver hair and hazel eyes. She wears worn clothing and a bronze amulet. Irefet has an animal companion, a ginger cat named Nefere.

### Drakesmoor Borough

 

#### NOTABLE PLACES:

 

-   The Guildhall: An impressive building of half-timbered walls, decorated with wrought-iron lamps. It contains a large meeting hall and several smaller rooms, and is shared amongst several local trade guilds.
-   An obelisk of polished stone, which shines with a cold light when the town is under threat.

#### A FEW NPCS:

 

-   Genefy: Male Dwarf Fighter, Evil. Genefy is repulsive in appearance, with grey hair and sharp amber eyes. He wears splint mail and wields a bastard sword and long bow. Genefy compulsively rhymes words.
-   Apun: Male Dwarf Merchant, Neutral. Apun is slender, with golden hair and large blue eyes. He wears worn clothing and carries a long knife. Apun has an animal companion, a hawk named Mosase.

### East Noble's Farthing

 

#### NOTABLE PLACES:

 

-   The Maiden's Rose: A grand adventurer's tavern, said to be built atop the tomb of a demon.
-   Nesemkhuy's Woodwork: A large woodcarver's workshop, built within a copse of elder trees.

#### A FEW NPCS:

 

-   Mutempy: Female Dwarf Mercenary, Good. Mutempy has matted grey hair and green eyes. She wears studded leather and wields a mace. Mutempy has an animal companion, a hunting dog named Tatise.
-   Heduathay: Female Dwarf Mercenary, Evil. Heduathay is fair in appearance, with red hair and narrow hazel eyes. She wears scale mail and wields a bardiche. Heduathay has an animal companion, a hawk named Djese.
-   Wepwadjmoy: Male Elf Assassin, Evil. Wepwadjmoy has a long face, with long white hair and amber eyes. He wears leather armor and wields a poisoned club. Wepwadjmoy is a pack-rat, and carries a satchel of random junk.
-   Itkates: Female Dwarf Mercenary, Neutral. Itkates is exceptionally beautiful, with tangled silver hair and green eyes. She wears scale mail and wields a fauchard-fork. Itkates seeks to free herself from an ancient curse.
-   Mere: Female Human Aristocrat, Good. Mere is fair in appearance, with copper hair and brown eyes. She wears fine raiment and jewelry. Mere is flamboyant and curious.
-   Ibifymo: Male Dwarf Wizard, Good. Ibifymo has cropped brown hair and brown eyes, and a thick moustache. He wears sturdy clothing and wields a quarterstaff. Ibifymo dislikes physical contact.

### East Yellowgate Ward

 

#### NOTABLE PLACES:

 

-   The Adventurers Guild House: A large stone-walled building, once an aristocrat's manor. It is said to be built atop an iron vault, which contains the library and archives of a defeated lich.

#### A FEW NPCS:

 

-   Imen: Male Dwarf Mercenary, Good. Imen is willowy, with white hair and narrow green eyes. He wears studded leather and wields a battle axe and shield. Imen is easily distracted by arcana.
-   Nakhte: Male Dwarf Paladin, Good. Nakhte is rough in appearance, with uneven silver hair and grey eyes. He wears splint mail and wields a military pick and shield. Nakhte is easily distracted by magic.
-   Sanebni: Male Dwarf Servant, Neutral. Sanebni is stout, with braided brown hair and narrow brown eyes. He wears simple clothing and riding boots. Sanebni seeks to atone for past sins.
-   Munesty: Male Dwarf Peasant, Neutral. Munesty is fey in appearance, with straight grey hair and brown eyes. He wears modest garments and a wide-brimmed hat. Munesty seeks to atone for past sins.

### Hell-hound's Village

 

#### NOTABLE PLACES:

 

-   The Buzzing Tower: An abandoned stone-walled tower, which has become infested by a colony of giant bees.
-   The Unicorn's Inn: A modest dwarven inn, built within what was once a wizard's tower.
-   The Guildhall: An ornate building of stone walls, decorated with a glazed-tile roof. It contains a large meeting hall and several smaller rooms, and is shared amongst several local trade guilds.

#### A FEW NPCS:

 

-   Wahka: Male Dwarf Fighter, Neutral. Wahka has thick auburn hair and hazel eyes, and walks with a limp. He wears banded mail and wields a mace. Wahka is jealous and ambitious.
-   Senebuy: Male Dwarf Peasant, Neutral. Senebuy has thick silver hair and large grey eyes, and a round nose. He wears modest garments and a pewter amulet. Senebuy has a sable ferret named Tjese.
-   Amenwah: Male Elf Craftsman, Evil. Amenwah is heavyset, with blonde hair and sharp amber eyes. He wears modest garments and carries a cedar staff. Amenwah was magically imprisoned for a hundred years.
-   Tetaty: Female Dwarf Aristocrat, Evil. Tetaty is beastly in appearance, with silver hair and narrow blue eyes. She wears fine raiment and silk gloves. Tetaty is impossibly lucky.
-   Baendjedhui: Male Dwarf Mercenary, Neutral. Baendjedhui is rugged in appearance, with matted red hair and hazel eyes. He wears scale mail and wields a battle axe and shield. Baendjedhui has an animal companion, a hawk named Pataha.

### Highsword Farthing

 

#### NOTABLE PLACES:

 

-   The College of Partius: A small school of witches and wizards, known for the living gargoyles which guard its walls.

#### A FEW NPCS:

 

-   Mese: Male Human Scholar, Good. Mese has a narrow face, with curly blonde hair and sharp green eyes. He wears expensive clothing and a silver amulet. Mese has an animal companion, a hunting dog named Ahon.
-   Merese: Female Dwarf Scofflaw, Good. Merese is exceptionally beautiful, with white hair and blue eyes. She wears worn clothing and a wooden holy symbol. Merese is valiant and witty.
-   Meryti: Female Dwarf Merchant, Evil. Meryti is fair in appearance, with grey hair and grey eyes. She wears plain clothing and a wooden holy symbol. Meryti blames trolls for every misfortune.
-   Nebna: Male Human Paladin, Good. Nebna has a long face, with matted red hair and grey eyes. He wears chain mail and wields a military pick and shield. Nebna seeks to atone for past sins.

### Hydra's Farthing

 

#### NOTABLE PLACES:

 

-   An ancient arch of dark stone, said to be the key to a planar gate.
-   Nefere's Masonry: A large stonemason's workshop, built around a shrine of Mere, Goddess of Earth.
-   Menumha's Pewter: The workshop of a male dwarf pewtersmith named Menumha, known for his vast knowledge of ancient elven scripts.

#### A FEW NPCS:

 

-   Merewy: Male Human Fighter, Good. Merewy has straight grey hair and soft green eyes. He wears plate mail and wields a short sword. Merewy has an animal companion, a red firedrake named Senmeky.
-   Senesmer: Female Dwarf Artist, Good. Senesmer has golden hair and brown eyes. She wears modest garments and a sling of vials and potions. Senesmer has an animal companion, a white rabbit named Nitare.
-   Munakhte: Male Dwarf Priest, Good. Munakhte is pleasant in appearance, with blonde hair and bright blue eyes. He wears modest garments and a sling of vials and potions. Munakhte is kind and faithful.
-   Nefere: Female Dwarf Scholar, Neutral. Nefere has an angular face, with curly silver hair and blue eyes. She wears modest garments and a dragonscale cloak. Nefere has an animal companion, a ginger ferret named Khefere.
-   Perrempta: Male Dwarf Servant, Evil. Perrempta is short, with straight brown hair and bright grey eyes. He wears simple clothing and carries a hawthorn staff. Perrempta is quiet and serious.
-   Tahuy: Female Human Wizard, Good. Tahuy has a long face, with auburn hair and dark grey eyes. She wears bronze robes and wields a dagger and sling. Tahuy has an arcane familiar, a floating lantern which pulses with light as it speaks.

### Knightskeep Farthing

 

#### NOTABLE PLACES:

 

-   The Keystone of Arah: A giant white keystone hangs in the air high above the street, fixed and immovable. It is said that anyone who touches the keystone is protected from evil for a year and a day.

#### A FEW NPCS:

 

-   Itehut: Female Dwarf Fighter, Evil. Itehut has a long face, with silver hair and narrow brown eyes. She wears banded mail and wields a military pick and javelins. Itehut is bloodthirsty and inventive.
-   Mery: Female Dwarf Scholar, Neutral. Mery has curly auburn hair and hazel eyes, and a sharp nose. She wears modest garments and a silver holy symbol. Mery has an animal companion, a grey rat named Menebty.
-   Mose: Male Human Cleric, Neutral. Mose has a long face, with golden hair and soft amber eyes. He wears chain mail and wields a club. Mose is crude and bold.

### Lower Rogue's Borough

 

#### NOTABLE PLACES:

-   The Jade Runestone: A broken obelisk of green jade, engraved with draconic runes. It is said that any child born within a league of the stone upon the night of the solstice will live a charmed life.

#### A FEW NPCS:

 

-   Mere: Female Dwarf Fighter, Good. Mere is tall, with uneven golden hair and light grey eyes. She wears plate mail and wields a short sword and javelins. Mere serves Sacha, an ancient but forgotten goddess of luck.
-   Mutufy: Male Human Alchemist, Good. Mutufy has brown hair and amber eyes. He wears modest garments and a mink fur cape. Mutufy is searching for his lost sister.
-   Hetwere: Female Human Merchant, Evil. Hetwere has blonde hair and blue eyes. She wears sturdy clothing and several pouches hang from her belt. Hetwere compulsively lies.
-   Atefen: Female Dwarf Alchemist, Evil. Atefen has a narrow face, with braided copper hair and light blue eyes. She wears modest garments and a silver holy symbol. Atefen has an animal companion, a red fox named Senmuni.

### Market

 

#### NOTABLE NPCS:

 

-   Bankhu: Male Dwarf Entertainer, Good. Bankhu has braided black hair and blue eyes, and a short moustache. He wears modest garments and silk gloves. Its hard to picture Bankhu as an adventurer, but he's said to be the best fighter in town.
-   Imamen: Female Dwarf Thief, Evil. Imamen is fair in appearance, with brown hair and narrow amber eyes. She wears leather armor and wields a long sword and darts. Imamen is known for her impossible luck.
-   Pionety: Male Dwarf Thief, Neutral. Pionety has an angular face, with brown hair and large hazel eyes. He wears leather armor and wields a long sword and dagger. Pionety was once an adventurer, but retired after his companions were slain in the Lost Sepulcher of Death.
-   Khnakhtahhuy: Male Dwarf Wineseller, Evil. Khnakhtahhuy has a narrow face, with blonde hair and blue eyes. He wears well-made clothing and several small tools hang from his belt. Its hard to picture Khnakhtahhuy as an adventurer, but he knows a great deal about every ruins within eight leagues of town.
-   Pameni: Male Dwarf Alchemist, Neutral. Pameni has an angular face, with curly silver hair and brown eyes. He wears expensive clothing and a copper amulet. Pameni was once a soldier, and specializes in potions of war.
-   Nefere: Female Dwarf Fishmonger, Evil. Nefere has uneven white hair and grey eyes. She wears well-made clothing and several small tools hang from her belt. Nefere sometimes has interesting items from sunken ships to sell.

### Palace Borough

 

#### NOTABLE PLACES:

 

-   The Minstrel and Cup: A heroic dwarven tavern, built within an ancient tower of rune-carved stone.
-   The Shrine of Mehirka: A stone statue of Mehirka, God of Animals, said to reveal visions to those who leave an offering.
-   The Clockwork: A large prism of rotating gears and ticking escapements, crafted from brass and inscribed with endless spirals. No-one seems to know who created it, nor when, nor its purpose.

#### A FEW NPCS:

 

-   Ithiamun: Female Elf Soldier, Neutral. Ithiamun is short and thin, with thick white hair and green eyes. She wears leather armor and wields a warhammer and shield. Ithiamun is haunted by the memories of a past life.
-   Nedjankhui: Male Dwarf Mercenary, Good. Nedjankhui is tall, with copper hair and large amber eyes. He wears leather armor and wields a flail and shield. Nedjankhui is philosophical but vengeful.
-   Khonse: Male Dwarf Peasant, Evil. Khonse has blonde hair and green eyes, and a small mouth. He wears modest garments and a wide-brimmed hat. Khonse seeks wealth and power at any cost.
-   Tempenre: Female Dwarf Wizard, Evil. Tempenre is fair in appearance, with matted white hair and brown eyes. She wears modest garments and wields a quarterstaff and dagger. Tempenre is searching for her missing son.
-   Pamutu: Male Dwarf Cleric, Good. Pamutu is elegant in appearance, with blonde hair and dark blue eyes. He wears chain mail and wields a club. Pamutu seeks to help the poor and unfortunate.

### Roseorb Farthing

 

#### NOTABLE PLACES:

 

-   Nefere's Pewter: A cluttered pewtersmith's workshop, sheltered beneath the wings of a pewter dragon.
-   Greenhome: A single storey stone-walled building which has been completely overgrown by flowering vines scale-like leaves thorny vines writhing vines. It is the home of Nocri, a young green dragon and linguist.
-   The ruins of Ufehun Tower.

#### A FEW NPCS:

 

-   Tempenre: Female Human Thief, Neutral. Tempenre has silver hair and green eyes. She wears leather armor and wields a short sword and dagger. Tempenre seeks to steal an ancient artifact from the School of the Elements.
-   Nebaka: Male Human Merchant, Good. Nebaka has short silver hair and sharp grey eyes. He wears sturdy clothing and several pouches hang from his belt. Nebaka has an animal companion, a green firedrake named Abadjet.
-   Khare: Female Human Scholar, Evil. Khare has white hair and brown eyes, and a flat nose. She wears fine clothing and a silver holy symbol. Khare has an animal companion, a red fox named Wabatau.
-   Nofre: Female Dwarf Paladin, Good. Nofre is thin, with silver hair and soft hazel eyes. She wears banded mail and wields a long sword and shield. Nofre is irreverent and modest.

### Rosescepter Village

 

#### NOTABLE PLACES:

 

-   The War Merchant: The cluttered shop of a male dwarf weapon merchant named Pashesy, known for his collection of strange and exotic blades. It is rumored that the weapons are those of fallen warriors, stolen from distant battlefields by dark magic.
-   The King's House: A neglected commoner's tavern, built within an ancient tower of rune-carved stone.
-   The Devil's Gallows: It is said that every thief and murderer condemned to these gallows whispers a dark secret or betrayal in the moment before they die.

#### A FEW NPCS:

 

-   Maatnefer: Female Dwarf Fighter, Neutral. Maatnefer has straight black hair and green eyes, and a sharp nose. She wears chain mail and wields a warhammer. Maatnefer is hunting the warlord who murdered her family.
-   Menamoy: Male Dwarf Paladin, Good. Menamoy has cropped white hair and bright hazel eyes. He wears splint mail and wields a bardiche. Menamoy has an animal companion, a bay warhorse named Mekemshu.
-   Numhotha: Male Dwarf Ranger, Neutral. Numhotha is tall and willowy, with blonde hair and dark brown eyes. He wears chain mail and wields a warhammer and light crossbow. Numhotha has a forest owl named Wennenkhe.

### Servant's District

 

#### NOTABLE PLACES:

 

-   Atenis' Clocks: A cluttered clockmaker's workshop, built within what was once an aristocrat's manor.

#### A FEW NPCS:

 

-   Neferai: Female Dwarf Peasant, Good. Neferai has curly brown hair and blue eyes, and a flat nose. She wears travel-stained clothing and carries a long knife. Neferai is thoughtful and amoral.
-   Aserrat: Male Dwarf Servant, Evil. Aserrat has blonde hair and brown eyes. He wears plain clothing and a green cloak. Aserrat is impossibly lucky.
-   Abet: Female Dwarf Fighter, Neutral. Abet has braided white hair and light green eyes, and a round nose. She wears chain mail and wields a military pick. Abet seeks to save her family from financial ruin.
-   Here: Female Dwarf Fighter, Evil. Here has long copper hair and bright brown eyes, and walks with a limp. She wears splint mail and wields a warhammer and javelins. Here lost her reflection to a nymph.
-   Weshkety: Female Dwarf Mercenary, Neutral. Weshkety has a round face, with blonde hair and soft grey eyes. She wears studded leather and wields a mace and dagger. Weshkety has an animal companion, a hunting dog named Sermere.

### Temple Ward

 

#### NOTABLE PLACES:

  

-   Munebi's Armaments: The workshop of a male dwarf weaponsmith named Munebi, known for his concealed weapons.
-   The Guardhouse: A buttressed stone-walled building, a station of of the town guard. It is built atop a small dungeon used to detain thieves and scofflaws.

#### A FEW NPCS:

 

-   Hefankha: Male Human Entertainer, Evil. Hefankha has auburn hair and dark green eyes, and an unusual mark on his arm. He wears fine clothing and a fox fur cape. Hefankha is a skilled cook.
-   Djetepuy: Male Human Fighter, Good. Djetepuy has long golden hair and sharp grey eyes. He wears chain mail and wields a military fork. Djetepuy seeks to free himself from an ancient curse.
-   Seneskhu: Female Dwarf Ranger, Neutral. Seneskhu is fey in appearance, with matted black hair and brown eyes. She wears studded leather and wields a spear. Seneskhu is impossibly lucky.
-   Tanodjmat: Female Dwarf Paladin, Good. Tanodjmat has straight red hair and large brown eyes. She wears plate mail and wields a short sword and shield. Tanodjmat seeks to destroy the undead.
-   Akhtenhah: Male Dwarf Druid, Neutral. Akhtenhah has cropped auburn hair and bright brown eyes, and large ears. He wears leather armor and wields a spear and sling. Akhtenhah is haunted by the memories of a past life.

### Tower Borough

 

#### NOTABLE PLACES:

  

-   Nebaony's Hauberks: The workshop of a male dwarf armorer named Nebaony, known for his exotic and monstrous hide armors.
-   The Bloody Thorn: A grand adventurer's tavern, decorated with exotic weapons and armor.

#### A FEW NPCS:

 

-   Sutahu: Male Dwarf Druid, Neutral. Sutahu is overweight, with curly black hair and light hazel eyes. He wears leather armor and wields a scimitar and dagger. Sutahu seeks to discover where he came from, and who his real family is.
-   Setayuhay: Female Dwarf Fighter, Evil. Setayuhay is fair in appearance, with tangled blonde hair and blue eyes. She wears plate mail and wields a warhammer and shield. Setayuhay has an animal companion, a grey wolf named Merure.
-   Nere: Female Dwarf Alchemist, Good. Nere is exceptionally beautiful, with copper hair and brown eyes. She wears fine clothing and an amulet of luminous crystal. Nere has an animal companion, a grey rat named Senefy.
-   Aneris: Female Dwarf Mercenary, Good. Aneris is tall, with short copper hair and narrow blue eyes. She wears leather armor and wields a warhammer and long bow. Aneris is romantic and anxious.
-   Merity: Female Dwarf Craftsman, Good. Merity has a round face, with red hair and sharp grey eyes. She wears simple clothing and carries an oak staff. Merity seeks only fame and glory.

### Points of interest

-   A statue of hewn crystal, placed to honor a local hero named Djedy.
-   A spire of dark stone, which floats several feet above the ground.

**Population**

50000

  [Quick Edit](https://www.worldanvil.com/world/explore/article/9b0d66c3-a07a-468a-a3e2-51120223ab8c/form)   [Edit](https://www.worldanvil.com/world/settlement/9b0d66c3-a07a-468a-a3e2-51120223ab8c/edit)  [Open in World](https://www.worldanvil.com/w/[[[[[[[[[[elinia]]]]]]]]]]-[[[[grivik]]]]/a/elcier-landing-settlement)

[](https://www.worldanvil.com/world/f67440a8-02a0-49e8-90eb-17e62b3c836d/summary#wrapper)

### Map
![[58e75de46f040c8f0cef18d6dcafbbf1.png]]

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Notable NPCs
Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Power
1.  Conventional (CG)
2.  Non-standard (LE)
3.  Magical (LN)
4.  Magical (LG)

## Internal Relationships
Placeholder

## Outward Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

