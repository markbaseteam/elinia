---

database-plugin: basic

---

<%%
name: new database
description: new description
columns:
  __file__:
    key: __file__
    input: markdown
    label: File
    accessor: __file__
    isMetadata: true
    skipPersist: false
    isDragDisabled: false
    csvCandidate: true
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: true
      source_data: current_folder
  Alignment:
    input: select
    key: Alignment
    accessor: Alignment
    label: Alignment
    position: 0
    options:
      - { label: "Chaotic Evil", backgroundColor: "hsl(185, 95%, 90%)"}
      - { label: "Neutral", backgroundColor: "hsl(110, 95%, 90%)"}
      - { label: "N/A", backgroundColor: "hsl(287, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
  Political-Region:
    input: select
    accessor: Political-Region
    key: Political-Region
    label: Political-Region
    position: 100
    options:
      - { label: "Province", backgroundColor: "hsl(268, 95%, 90%)"}
      - { label: "Nation", backgroundColor: "hsl(41, 95%, 90%)"}
      - { label: "Town", backgroundColor: "hsl(36, 95%, 90%)"}
      - { label: "City", backgroundColor: "hsl(3, 95%, 90%)"}
      - { label: "Metropolis ", backgroundColor: "hsl(119, 95%, 90%)"}
      - { label: "Metropolis", backgroundColor: "hsl(144, 95%, 90%)"}
      - { label: "Tavern", backgroundColor: "hsl(137, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Community-Size:
    input: select
    accessor: Community-Size
    key: Community-Size
    label: Community-Size
    position: 100
    options:
      - { label: "City", backgroundColor: "hsl(146, 95%, 90%)"}
      - { label: "Metropolis", backgroundColor: "hsl(126, 95%, 90%)"}
      - { label: "Outpost", backgroundColor: "hsl(146, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Government:
    input: select
    accessor: Government
    key: Government
    label: Government
    position: 100
    options:
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Type:
    input: select
    accessor: Type
    key: Type
    label: Type
    position: 100
    options:
      - { label: "Country ", backgroundColor: "hsl(56, 95%, 90%)"}
      - { label: "Building", backgroundColor: "hsl(336, 95%, 90%)"}
      - { label: "Metropolis", backgroundColor: "hsl(103, 95%, 90%)"}
      - { label: "Planet", backgroundColor: "hsl(1, 95%, 90%)"}
      - { label: "Area", backgroundColor: "hsl(260, 95%, 90%)"}
      - { label: "City", backgroundColor: "hsl(6, 95%, 90%)"}
      - { label: "Town", backgroundColor: "hsl(29, 95%, 90%)"}
      - { label: "Country", backgroundColor: "hsl(213, 95%, 90%)"}
      - { label: "Tectonic plate ", backgroundColor: "hsl(96, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Terrain:
    input: text
    accessor: Terrain
    key: Terrain
    label: Terrain
    position: 100
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Climate:
    input: text
    accessor: Climate
    key: Climate
    label: Climate
    position: 100
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Geographical-Region:
    input: text
    accessor: Geographical-Region
    key: Geographical-Region
    label: Geographical-Region
    position: 100
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  Tags:
    input: tags
    accessor: Tags
    key: Tags
    label: Tags
    position: 100
    options:
      - { label: "Category/Region--Geographical", backgroundColor: "hsl(222, 95%, 90%)"}
      - { label: "Category/Region--Political", backgroundColor: "hsl(211, 95%, 90%)"}
      - { label: "Category/Named-Equipment", backgroundColor: "hsl(93, 95%, 90%)"}
      - { label: "Category/Adventure-Area", backgroundColor: "hsl(280, 95%, 90%)"}
      - { label: "Category/Settlement", backgroundColor: "hsl(349, 95%, 90%)"}
      - { label: "Category/Location", backgroundColor: "hsl(117, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
config:
  enable_show_state: false
  group_folder_column: 
  remove_field_when_delete_column: false
  cell_size: normal
  sticky_first_column: false
  show_metadata_created: false
  show_metadata_modified: false
  source_data: current_folder
  source_form_result: root
filters:
%%>