---
Type: Building
Political-Region: Tavern
---
### Menu 

-   Boiled Eggs and Turnip, Tankard of Bitter (11 cp)
-   Stewed Deer and Dried Beetroot, Tankard of Ale (10 cp)
-   Boiled Eggs and Soft Cheese, Tankard of Bitter (10 cp)
-   Boiled Eggs and Dried Watercress, Tankard of Beer (8 cp)
-   Roasted Carrot, Mug of Perry (5 cp)
-   Wheat Porridge, Mug of Perry (3 cp)



### Denizens

The innkeeper is a young female human named Britha.

**Type**

Inn

**Parent Location**

[[CAER KONIG]]

#### PATRONS

-   Mena: Female Halfling Fighter, Neutral. Mena has a long face, with black hair and light amber eyes. She wears plate mail and wields a short sword and shield. Mena compulsively sings.
-   Piersym Nysev: Male Human Druid, Neutral. Piersym has uneven auburn hair and blue eyes. He wears leather armor and wields a quarterstaff. Piersym is haunted by the memories of a past life.
-   Icet: Female Human Fighter, Neutral. Icet has copper hair and green eyes, and large ears. She wears plate mail and wields a spear and dagger. Icet is searching for the lost elven kingdom of Esseamas.
-   Hamfo: Male Halfling Druid, Neutral. Hamfo is fair in appearance, with curly brown hair and hazel eyes. He wears leather armor and wields a quarterstaff and sling. Hamfo seeks to free himself from an ancient curse.
-   Scana: Female Elf Necromancer, Evil. Scana has white hair and hazel eyes, and prominent ears. She wears modest garments and wields a short sword and dagger. Scana is hunting the sorceress who stole her husband.
-   Eanwild: Female Human Fighter, Evil. Eanwild has matted black hair and bright brown eyes. She wears banded mail and wields a mace. Eanwild is talking quietly with a female human aristocrat.

#### RUMORS

 

1.  A star has fallen into the Sea of Moda.
2.  A perpetual storm rages over the Avog Forest.
3.  The town was built on top of the lair of an ancient dragon.
4.  The silver dragon of the Black Halls of Death sometimes helps adventurers.
5.  An order of evil cultists lurks in the sewers and tunnels beneath the town.
6.  The ravens of the Woeful Fells have gained sentience and speech.
7.  The town of Ullcot has mysteriously disappeared.
8.  Hundreds of bats were seen circling Ritha, who seemed to whisper to them.




