---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Named-Equipment
Equipment-Type: Weapon
parent:
 - Named Equipment
up:
 - Named Equipment
prev:
 - Template - Inhabitant
next:
 - Template - Named Object
RWtopicId: Topic_30
Alignment: N/A
Type: Building
---
# Ancient Forge
## Overview
**Equipment Type**: Weapon, Protection, Clothing, Accessory, Gear, Other

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Relationships
[[Forge District]]


## Equipping
Placeholder

## Capabilities
Placeholder

## Components
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

