---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Settlement
Community-Size: City
Alignment: Neutral
Government: Autocracy
parent:
 - Settlement
up:
 - Settlement
prev:
 - Template - Region_ Area
next:
 - Template - Inhabitant
RWtopicId: Topic_28
Political-Region: City
Type: City
---
# City of Wehstead
![[87d89133f3c426ac639eda2bfb0f8b15.jpg]]



## Overview
**Community Size**: Large City


**Government**: Democracy

**Defense**: Placeholder

**Commerce**: Placeholder

**Organizations**: Placeholder

Placeholder

## Description
**Population**: Placeholder


## Notable NPCs
Placeholder

## Population
50,000

## Story
Placeholder

## Points of Interest
[[Lazarus Engine]]

## Valuables
Placeholder

## Internal Relationships
Placeholder

## Outward Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

