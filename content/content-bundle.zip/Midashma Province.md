---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Region--Geographical
Geographical-Region: Mountains
Terrain: Swamp
Climate: Arctic
parent:
 - Region_ Geographical
up:
 - Region_ Geographical
prev:
 - Template - Region_ Deimensional
next:
 - Template - Region_ Political
RWtopicId: Topic_25
Type: Country 
---
# Midashma Province
## Overview
**Geographical Region**: Mountains, Hills, Plains, Forest, Swamp, Marsh, Jungle, Rainforest, Lake, River, Bay, Reef, Peninsula, Isthmus, Strait, Cove, Delta, Canyon, Glacier, Plateau, Valley, Oasis, Coast, Pass, Continent, Subcontinent, Island, Archipelago, Other, Travel Route, Body of Water, Gulf, Ocean, Sea

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Description
**Terrain**: Swamp, Jungle, Rocky, Treacherous, Rainforest, Badlands, Croplands, Deserts, Forests, Grasslands, Hills, Mountains, Other, Tundra, Underground, Urban, Water, Marsh, Coastal, Volcanic

**Climate**: Arctic, Arid, Other, Subtropical, Temperate, Tropical ;

### Placeholder Map
![[z_Assets/Misc/MapPlaceholder.png|Placeholder Map]]
[[z_Assets/Misc/MapPlaceholder.png|open outside]]

Placeholder

## Notable NPCs
Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Resources
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

