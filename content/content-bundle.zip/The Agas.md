---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Location
Type: Building
parent:
 - Location
up:
 - Location
prev:
 - Template - Adventure Area
next:
 - Template - Merchant
RWtopicId: Topic_21
---
# The Agas
## Overview
**Type**: Area, Facility, Point of Interest, Compound, Access Point, Anomaly, Building, Chamber, Corridor, Landmark, Level, Marker, Open Space, Other, Room, Waypoint

The Agas is a hollow temple deep underneath the central castle of [Vin'Gurahm](https://www.worldanvil.com/w/elderforge-proteinmaster/a/vin-gurahm-settlement) and is wreathed in flames. Molten magma covers the ground and lava drips from stalagmites. It is said that at the center of this ancient temple contains the long dead heart of a God made out of pure, powerful fire that only the worthy can withstand and be purified.

## Description
### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Challenges
Placeholder

## Obstacles
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

