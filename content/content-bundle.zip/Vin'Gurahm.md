---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Settlement
Community-Size: City
Alignment: Neutral
Government: Autocracy
parent:
 - Settlement
up:
 - Settlement
prev:
 - Template - Region_ Area
next:
 - Template - Inhabitant
RWtopicId: Topic_28
---
# Template - Settlement
## Overview
**Community Size**: Outpost

**Alignment**: Chaotic Evil

**Government**: Autocracy, Bureaucracy, Confederacy, Democracy, Dictatorship, Feudalism, Gerontocracy, Hierarchy, Kleptocracy, Magocracy, Matriarchy, Meritocracy, Militocracy, Monarchy, Oligarchy, Patriarchy, Plutocracy, Republic, Satrapy, Theocracy ;

**Defense**: Placeholder

**Commerce**: Placeholder

**Organizations**: Placeholder

**Founding Date**

-4900

**Type**

Underground / Vault

**Population**

8000

**Location under**

[Tarus](https://www.worldanvil.com/w/elderforge-proteinmaster/a/tarus-location)

**Owner/Ruler**

[Thorom Fireborn](https://www.worldanvil.com/w/elderforge-proteinmaster/a/thorom-fireborn-person)

**Ruling/Owning Rank**

[Firecrown](https://www.worldanvil.com/w/elderforge-proteinmaster/a/firecrown-rank)

**Characters in Locati**

## Description
An underground city built into and underneath the massive [Twin Peaks](https://www.worldanvil.com/w/elderforge-proteinmaster/a/twin-peaks-location) of the [Tarus Kingdom](https://www.worldanvil.com/w/elderforge-proteinmaster/a/tarus-location). The city is known for it's sprawling underground system that connects it to all other Dwarven cities located in the Kingdom, allowing swift reinforcements in time of need. Vin'Gurahm is also known for it's rich supply of mineral and ore, the biggest supplier in all of Velaria.

### Placeholder Map
![[z_Assets/Misc/MapPlaceholder.png|Placeholder Map]]
[[z_Assets/Misc/MapPlaceholder.png|open outside]]

### Placeholder Picture
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Picture]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Notable NPCs
Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Internal Relationships
Placeholder

## Outward Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder


