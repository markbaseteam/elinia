---
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
Tags: Category/Location
Type: Area
parent:
  - Location
up:
  - Location
prev:
  - Template - Adventure Area
next:
  - Template - Merchant
RWtopicId: Topic_21
---
# The Doorforge
## Overview
**Type**: Area, Facility, Point of Interest, Compound, Access Point, Anomaly, Building, Chamber, Corridor, Landmark, Level, Marker, Open Space, Other, Room, Waypoint

The Doorforge is a massive, labyrinthine factory where the doors to alternate dimensions are created and destroyed. No one knows who built it. No one knows who runs it now. But it does keep running...somehow.

Deep inside The Doorforge is The Nexus Tap & Doorhouse, a tavern where adventurers from many worlds gather to drink, sleep, exchange ideas, trade strange objects, and take various jobs from all over the infinities. Not everyone there gets along, but people know to keep their mischief in check when in the Nexus...it's either that, or Harry Brewback will have you thrown out one of its many doors into some unknown dimension. Getting back can be difficult, depending on where you get tossed.

## Description
![[7a1dbf3e699a09a4f2f2c257393cd4eb.jpg]]



## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Challenges
Placeholder

## Obstacles
Placeholder

## Relationships
[[Elinia]]

## Background
Placeholder

## Additional Details
Placeholder

