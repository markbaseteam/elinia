# New Settlement

## Demographics

**Total Population:** 11631
**Primary Race:** Half-Elf
**General Attitude:** Indifferent and Xenophobic

h4. Breakdown

* **Children:** 1977
* **Adults:** 8375
* **Elderly:** 1279
* *Ill/Infirm:* 1220
* **Known Criminals:** 96
* **Urban Population:** 8884
* **Rural Population:** 2747

## Infrastructure

**Road Construction:** Wood Lined Roads
**Main Irrigation:** Surge Irrigation
**Number of Districts:** 5

## Architecture

### Overall Architecture

* **Primary Building Style:** Brick
* **Secondary Building Styles:** Wooden, Concrete, and Thatched
* **Aesthetics:** Utilitarian
* **Cleanliness:** dirty
* **Upkeep:** Lived-in

### Districts

#### District 1

* **Type:** Slum
* **Population:** 1066
* **Primary Building Style:** Thatched
* **Secondary Building Styles:** None
* **Aesthetics:** Utilitarian
* **Cleanliness:** Foul
* **Upkeep:** Shabby

#### District 2

* **Type:** Military
* **Population:** 1421
* **Primary Building Style:** Brick
* **Secondary Building Styles:** None
* **Aesthetics:** Utilitarian
* **Cleanliness:** Immaculate
* **Upkeep:** Impeccable

#### District 3

* **Type:** Market
* **Population:** 622
* **Primary Building Style:** Wooden
* **Secondary Building Styles:** None
* **Aesthetics:** Basic
* **Cleanliness:** Disorderly
* **Upkeep:** Handsome

#### District 4

* **Type:** Merchant
* **Population:** 800
* **Primary Building Style:** Wooden
* **Secondary Building Styles:** Brick
* **Aesthetics:** Functional
* **Cleanliness:** dirty
* **Upkeep:** Lived-in

#### District 5

* **Type:** Industrial
* **Population:** 89
* **Primary Building Style:** Brick
* **Secondary Building Styles:** None
* **Aesthetics:** Utilitarian
* **Cleanliness:** Foul
* **Upkeep:** Handsom

## Defenses

**Walls:** None
**Natural Defences:** Mangrove Swamp, Wide River, Cuesta, and Bluff

## Points of Interest

### Special Features

* **Insect Mounds:** 7.01 km southwest
* **Cuesta:** 7.19 km west
* **Burned Forest:** 1.89 km southeast
* **Bluff:** 6.05 km east
* **Cliff:** 2.73 km southeast

## Geography

*Coastal Marine Mangrove Swamp*
**Elevation:** 3 m above sea level
**Distance from the Marine Coast:** 2.90 km
**Ground Cover:** 97%

### Water Features

h4. Sea

* **Salinity:** briny
* **Depth:** 86 m
* **Navigable:** Yes

h4. Wide River

* **Salinity:** fresh
* **Depth:** 86 m
* **Width:** 16.01 km
* **Navigable:** Yes
* **Aquatic Animals:** Catfish and Trout

## Climate

*Tropical Rain Forest*
*Avg. Annual Temperature:* 28C
*Avg. Annual Precipitation:* 5.70 m
**Seasons:** Dry Season and Wet Season
**Prevailing Winds:** southeast to northwest
**Ocean Currents:** warm

## Natural Resources

### Stones

* **Igneous:** Granite
* **Metamorphic:** Slate
* **Sedimentary:** Limestone and Laterite

### Ores

* **Minerals:** Borax

### Gems

* *Semi-Precious:* Agate

### Grains

* **Warm Seasons:** Amaranth, Kiwicha, and Millet
* **Food:** Amaranth, Kiwicha, and Millet

### Vegetables

* **Root:** Sweet Potato and Potato
* **Marrow:** Cucumber

### Utility Crops

* **Fiber:** Kenaf

## Assets

### Stone Quarries

h4. Quarry

* Gathers Laterite
* 29 workers

h4. Rock Pit

* Gathers Granite
* 12 workers

h4. Rock Pit

* Gathers Limestone
* 7 workers

h4. Rock Pit

* Gathers Slate
* 14 workers

### Lumber Camps

h4. Woodcutter's Camp

* Gathers Sandalwood
* 52 workers

## Flora and Fauna

* **Livestock:** Adamawa (Cattle)
* **Prey:** Warthogs
* **Aquatic:** Trout and Catfish
* **Trees:** Ramin, Cumaru, Sandalwood, and Lemon Tree
* **Grass:** Tufted Hair Grass, Feather Reed, Leafy Reedgrass, Grey Fescue Grass, and Blue Fescue Grass
* **Shrubs:** Blueberry Bush, Strawberry Bush, Lentil Plant, Abelia, Black Chokeberry, and Raspberry Bush
* **Moss:** Tamarisk Moss, Catherine's Moss, Fern Moss, Brocade Moss, and Haircap Moss
* **Vines:** Madeira Vine, Poison Ivy, and Bridal Creeper

