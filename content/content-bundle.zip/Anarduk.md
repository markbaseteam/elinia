---
ImportedOn: "Saturday, 18 December 2021 8:41:47 PM"
Tags: Category/Region--Political
Political-Region: Nation
Alignment: Chaotic Evil
parent:
 - Region_ Political
up:
 - Region_ Political
prev:
 - Template - Region_ Geographical
next:
 - Template - Region_ Area
RWtopicId: Topic_26
Type: Tectonic plate 
---
# Template - Region: Political
## Overview
**Political Region**: Nation, State, County, Quadrant, Sector, Territory, Province, Protectorate, Colony, Sphere of Influence, Other, Empire

**Alignment**: Chaotic Evil, Chaotic Good, Chaotic Neutral, Lawful Evil, Lawful Good, Lawful Neutral, Neutral, Neutral Evil, Neutral Good, Unaligned

**Seat of Power**: Placeholder

**Major Races/Ethnicities**: Placeholder

**Government**: Placeholder

**Languages**: Placeholder

**Religion**: Placeholder

### Placeholder Flag/Symbol
![[z_Assets/Misc/ImagePlaceholder.png|Placeholder Flag/Symbol]]
[[z_Assets/Misc/ImagePlaceholder.png|open outside]]

Placeholder

## Description
### Placeholder Map
![[z_Assets/Misc/MapPlaceholder.png|Placeholder Map]]
[[z_Assets/Misc/MapPlaceholder.png|open outside]]

Placeholder

## Notable NPCs
Placeholder

## Profile
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Resources
Placeholder

## Relationships
Placeholder

## Background
Placeholder

## Additional Details
Placeholder

